from django.contrib import admin
from django import forms
from ckeditor.widgets import CKEditorWidget
from .models import (
    AboutPage, ContactUs_Page, ContactFormSubmission, SocialMediaLink, TermsPage,
    PrivacyPolicyPage, Category, CategoryMeta, Video, Author, Article, ArticleDetails,
    CategoryArticleCount, Comment, PageMeta, Subscription, TelegramSettings,
    InterviewArticle, URLRedirect
)

# ---------------- INLINE FORMS ---------------- #

class ArticleDetailsInlineForm(forms.ModelForm):
    discription = forms.CharField(widget=CKEditorWidget(), required=False)

    class Meta:
        model = ArticleDetails
        fields = '__all__'

class ArticleDetailsInline(admin.StackedInline):
    model = ArticleDetails
    form = ArticleDetailsInlineForm
    extra = 1
    fieldsets = (
        (None, {
            'fields': (
                ('title', 'alt_text'),
                'discription',
                'image',
            )
        }),
    )

class CommentInline(admin.StackedInline):
    model = Comment
    extra = 1
    fields = ('name', 'email', 'body', 'created_on', 'active')

class CategoryMetaInline(admin.StackedInline):
    model = CategoryMeta
    extra = 1
    fields = ('meta_title', 'meta_description', 'meta_keywords', 'h1_tag')


# ---------------- CUSTOM ARTICLE ADMIN ---------------- #

class ArticleAdminForm(forms.ModelForm):
    description = forms.CharField(widget=CKEditorWidget(), required=False)

    class Meta:
        model = Article
        fields = '__all__'

@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    form = ArticleAdminForm
    list_display = ('article_title_h1', 'author', 'article_uploaded_date', 'active_status')
    list_filter = ('top_article', 'popular', 'trending', 'hot_news', 'active_status')
    search_fields = ('article_title_h1', 'meta_title')
    prepopulated_fields = {"article_slug": ("meta_title",)}
    inlines = [ArticleDetailsInline, CommentInline]


# ---------------- CUSTOM CATEGORY ADMIN ---------------- #

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('category_name', 'popular')
    inlines = [CategoryMetaInline]


# ---------------- OTHER MODELS ---------------- #

@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'date', 'popular')

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name',)

@admin.register(InterviewArticle)
class InterviewArticleAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at')

@admin.register(PageMeta)
class PageMetaAdmin(admin.ModelAdmin):
    list_display = ('page_name', 'meta_title', 'og_title')

@admin.register(URLRedirect)
class URLRedirectAdmin(admin.ModelAdmin):
    list_display = ('old_path', 'new_url')

@admin.register(ContactFormSubmission)
class ContactFormSubmissionAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone')

@admin.register(CategoryArticleCount)
class CategoryArticleCountAdmin(admin.ModelAdmin):
    list_display = ('category_name', 'article_count')

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('email', 'created_at')

@admin.register(TelegramSettings)
class TelegramSettingsAdmin(admin.ModelAdmin):
    list_display = ('chat_id',)


# ---------------- SIMPLE MODELS ---------------- #

admin.site.register(AboutPage)
admin.site.register(ContactUs_Page)
admin.site.register(SocialMediaLink)
admin.site.register(TermsPage)
admin.site.register(PrivacyPolicyPage)
